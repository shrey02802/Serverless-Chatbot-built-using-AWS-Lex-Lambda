def lambda_handler(event, context):
    intent_name=event['sessionState']['intent']['name']

    if intent_name == "CheckOrderStatus":
        return {
            "sessionState":{
                "dialogAction": {"type":"close"},
                "intent":{"name":"CheckOrderStatus", "state":"Fullfilled"}
            },
            "messages":[{
                "contentType":"PlainText",
                "content": f"your order {event['sessionState']['intent']['slot']['OrderId']['value']['interpretedValue']} is being processed."
            }]
        }
    else:
        return {
           
            "sessionState":{
                "dialogAction": {"type":"close"},
                "intent":{"name":"intent_name", "state":"Fullfilled"}
            },
            "messages": [{
                "contentType":"PlainText",
                "content": "Sorry, i didnt understood it"
            }]
        }    